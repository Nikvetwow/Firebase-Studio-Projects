'use client';

import { Heart, Coins, Timer, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

type HUDProps = {
  lives: number;
  coinsRemaining: number;
  level: number;
  timeLeft: number;
  onLevelRestart: () => void;
};

export function HUD({ lives, coinsRemaining, level, timeLeft, onLevelRestart }: HUDProps) {
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  return (
    <div className="w-full max-w-[800px] grid grid-cols-2 items-center p-2 mb-2 text-foreground font-headline rounded-md bg-black/20">
      <div className="flex items-center gap-4 text-2xl justify-self-start">
        <Button onClick={onLevelRestart} variant="ghost" size="sm" disabled={lives <= 1} className="text-foreground hover:bg-black/20 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed">
          <RefreshCw className="w-5 h-5 mr-2" />
          Restart Level
        </Button>
        <div className="text-3xl font-bold">
          Level {level}
        </div>
      </div>
      <div className="flex items-center gap-4 text-2xl justify-self-end">
         <div className="flex items-center gap-1">
          {Array.from({ length: lives }).map((_, i) => (
            <Heart key={i} className="w-8 h-8 text-red-500 fill-current" />
          ))}
        </div>
        <div className="flex items-center gap-2">
            <Timer className={`w-8 h-8 ${timeLeft <= 30 ? 'text-destructive animate-pulse' : 'text-accent'}`} />
            <span className={`font-bold ${timeLeft <= 30 ? 'text-destructive animate-pulse' : ''}`}>{formatTime(timeLeft)}</span>
        </div>
        <div className="flex items-center gap-2">
            <Coins className="w-8 h-8 text-accent" />
            <span className="font-bold">{coinsRemaining}</span>
        </div>
      </div>
    </div>
  );
}
