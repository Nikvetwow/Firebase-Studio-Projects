'use client';

import { useState, useEffect, useRef } from 'react';
import type { Level, Vector2D } from '@/lib/game/types';
import { useGameLoop } from '@/hooks/use-game-loop';
import { usePlayerInput } from '@/hooks/use-player-input';
import {
  GAME_WIDTH,
  GAME_HEIGHT,
  PLAYER_WIDTH,
  PLAYER_HEIGHT,
  PLAYER_SPEED,
  JUMP_STRENGTH,
  GRAVITY,
  ENEMY_WIDTH,
  ENEMY_HEIGHT,
  COIN_SIZE,
  ENEMY_SPEED,
} from '@/lib/game/constants';
import { SoundManager } from '@/lib/game/sounds';
import { HUD } from './HUD';
import { cn } from '@/lib/utils';
import { Coins } from 'lucide-react';

const LEVEL_TIME_SECONDS = 300; // 5 minutes

type PlayerState = {
  pos: Vector2D;
  vel: Vector2D;
  onGround: boolean;
  isJumping: boolean;
  jumpsLeft: number;
};

type EnemyState = {
  id: string;
  pos: Vector2D;
  vel: Vector2D;
  patrolRange: { startX: number; endX: number };
};

type CoinState = {
  id: string;
  pos: Vector2D;
};

type Cloud = {
    top: number;
    left: number;
    scale: number;
    speed: number;
}

type GameAreaProps = {
  level: Level;
  onLevelComplete: () => void;
  onPlayerDeath: () => void;
  onLevelRestart: () => void;
  lives: number;
  levelIndex: number;
  sunPosition: { top: number, left: number } | null;
  clouds: Cloud[];
};

export function GameArea({ level, onLevelComplete, onPlayerDeath, onLevelRestart, lives, levelIndex, sunPosition, clouds }: GameAreaProps) {
  const input = usePlayerInput();
  const playerRef = useRef<PlayerState>({
    pos: { ...level.playerStart },
    vel: { x: 0, y: 0 },
    onGround: false,
    isJumping: false,
    jumpsLeft: 2,
  });
  
  const [playerVisualPos, setPlayerVisualPos] = useState<Vector2D>({ ...level.playerStart });
  const [playerDirection, setPlayerDirection] = useState<'left' | 'right'>('right');
  const [isPlayerMoving, setIsPlayerMoving] = useState(false);

  const [enemies, setEnemies] = useState<EnemyState[]>(() =>
    level.enemies.map(e => ({
      ...e,
      pos: { ...e.position },
      vel: { x: e.patrolRange && e.patrolRange.startX !== e.patrolRange.endX ? ENEMY_SPEED : 0, y: 0 },
    }))
  );
  
  const [coins, setCoins] = useState<CoinState[]>(() =>
    level.coins.map(c => ({...c, pos: {...c.position}}))
  );

  const [timeLeft, setTimeLeft] = useState(LEVEL_TIME_SECONDS);
  const [showHurry, setShowHurry] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prevTime => {
        if (prevTime <= 1) {
          clearInterval(timer);
          onPlayerDeath();
          return 0;
        }
        if (prevTime === 31) {
          setShowHurry(true);
          setTimeout(() => setShowHurry(false), 5000);
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onPlayerDeath]);

  const checkAABBCollision = (obj1: {pos: Vector2D, w: number, h: number}, obj2: {pos: Vector2D, w: number, h: number}) => {
    return (
      obj1.pos.x < obj2.pos.x + obj2.w &&
      obj1.pos.x + obj1.w > obj2.pos.x &&
      obj1.pos.y < obj2.pos.y + obj2.h &&
      obj1.pos.y + obj1.h > obj2.pos.y
    );
  };

  useGameLoop(() => {
    const player = playerRef.current;
    
    // Player input
    player.vel.x = 0;
    if (input.ArrowLeft) {
      player.vel.x = -PLAYER_SPEED;
      setPlayerDirection('left');
    }
    if (input.ArrowRight) {
      player.vel.x = PLAYER_SPEED;
      setPlayerDirection('right');
    }
    
    setIsPlayerMoving(input.ArrowLeft || input.ArrowRight);

    if (input.Space && !player.isJumping && player.jumpsLeft > 0) {
      player.vel.y = -JUMP_STRENGTH;
      player.onGround = false;
      player.isJumping = true;
      player.jumpsLeft--;
      // SoundManager.jump();
    }
    if(!input.Space) {
        player.isJumping = false;
    }

    // Player physics
    player.vel.y += GRAVITY;
    const nextPos = { x: player.pos.x + player.vel.x, y: player.pos.y + player.vel.y };
    player.onGround = false;

    // Platform collision
    for (const platform of level.platforms) {
        // Vertical collision
        if (checkAABBCollision({pos: {x: player.pos.x, y: nextPos.y}, w: PLAYER_WIDTH, h: PLAYER_HEIGHT}, {pos: platform.position, w: platform.width, h: platform.height})) {
            if (player.vel.y > 0) { // Moving down
                nextPos.y = platform.position.y - PLAYER_HEIGHT;
                player.vel.y = 0;
                player.onGround = true;
                player.jumpsLeft = 2; // Reset jumps when landing
            } else if (player.vel.y < 0) { // Moving up
                nextPos.y = platform.position.y + platform.height;
                player.vel.y = 0;
            }
        }
        // Horizontal collision
        if (checkAABBCollision({pos: {x: nextPos.x, y: player.pos.y}, w: PLAYER_WIDTH, h: PLAYER_HEIGHT}, {pos: platform.position, w: platform.width, h: platform.height})) {
            if (player.vel.x > 0) { // Moving right
                nextPos.x = platform.position.x - PLAYER_WIDTH;
            } else if (player.vel.x < 0) { // Moving left
                nextPos.x = platform.position.x + platform.width;
            }
            player.vel.x = 0;
        }
    }
    
    player.pos = nextPos;
    
    // Boundaries
    if (player.pos.x < 0) player.pos.x = 0;
    if (player.pos.x > GAME_WIDTH - PLAYER_WIDTH) player.pos.x = GAME_WIDTH - PLAYER_WIDTH;
    if (player.pos.y > GAME_HEIGHT) onPlayerDeath();
    
    setPlayerVisualPos({ x: player.pos.x, y: player.pos.y });

    // Enemy logic
    setEnemies(prevEnemies => prevEnemies.map(enemy => {
        let newVelX = enemy.vel.x;
        const newPos = { ...enemy.pos };

        if (enemy.patrolRange && typeof enemy.patrolRange.startX === 'number' && typeof enemy.patrolRange.endX === 'number' && enemy.patrolRange.startX !== enemy.patrolRange.endX) {
            if (newVelX === 0) newVelX = ENEMY_SPEED; // Start moving if patrol range is set but velocity is 0
            
            newPos.x += newVelX;

            if (newPos.x <= enemy.patrolRange.startX || newPos.x >= enemy.patrolRange.endX - ENEMY_WIDTH) {
                newVelX *= -1;
            }
        } else {
          // If there's no patrol range, the enemy doesn't move.
          newVelX = 0;
        }

        return { ...enemy, pos: newPos, vel: { ...enemy.vel, x: newVelX} };
    }));

    // Collision with enemies and coins
    const playerBounds = { pos: player.pos, w: PLAYER_WIDTH, h: PLAYER_HEIGHT };
    for (const enemy of enemies) {
      if (checkAABBCollision(playerBounds, {pos: enemy.pos, w: ENEMY_WIDTH, h: ENEMY_HEIGHT})) {
        onPlayerDeath();
        return;
      }
    }
    
    let collectedCoin = false;
    const newCoins = coins.filter(coin => {
      const coinIsAtPlayerStart = coin.pos.x === level.playerStart.x && coin.pos.y === level.playerStart.y;
      if (coinIsAtPlayerStart) return true;

      if(checkAABBCollision(playerBounds, {pos: coin.pos, w: COIN_SIZE, h: COIN_SIZE})) {
        SoundManager.coin();
        collectedCoin = true;
        return false;
      }
      return true;
    });

    if(collectedCoin) {
      setCoins(newCoins);
      if(newCoins.length === 0) {
        onLevelComplete();
      }
    }
  });

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const playerLegMovementClass = isPlayerMoving && playerRef.current.onGround ? 'animate-walk' : '';


  return (
    <div className="flex flex-col items-center">
      <HUD lives={lives} coinsRemaining={coins.length} level={levelIndex + 1} timeLeft={timeLeft} onLevelRestart={onLevelRestart} />
      <div
        className="relative bg-[#a2d2ff] overflow-hidden border-4 border-primary/50 rounded-lg shadow-2xl"
        style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}
      >
        {sunPosition && (
          <div 
            className="absolute w-24 h-24"
            style={{ top: `${sunPosition.top}%`, left: `${sunPosition.left}%`, transform: 'translate(-50%, -50%)' }}
          >
            <svg viewBox="0 0 1024 1024" className="w-full h-full">
              <defs>
                <radialGradient id="sun-gradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                  <stop offset="0%" style={{stopColor: '#FFEDA0'}} />
                  <stop offset="50%" style={{stopColor: '#FFD700'}} />
                  <stop offset="100%" style={{stopColor: '#FFA500'}} />
                </radialGradient>
                <filter id="sun-glow" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur in="SourceGraphic" stdDeviation="20" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
              
              {/* Sun Rays */}
              {[...Array(60)].map((_, i) => {
                const angle = i * 6;
                const length = 400 + (Math.sin(i * 10) * 50);
                const width = 15 + (Math.cos(i*5) * 5);
                return (
                  <path
                    key={`ray-${i}`}
                    d={`M 512 512 L ${512 + length * Math.cos(angle * Math.PI / 180)} ${512 + length * Math.sin(angle * Math.PI / 180)}`}
                    strokeWidth={width}
                    stroke="rgba(255, 223, 138, 0.4)"
                    strokeLinecap="round"
                    style={{
                      filter: 'url(#sun-glow)',
                      transformOrigin: '512px 512px',
                    }}
                  />
                )
              })}

              {/* Sun Body */}
              <circle cx="512" cy="512" r="280" fill="url(#sun-gradient)" style={{filter: 'url(#sun-glow)'}} />
              
              {/* Cheeks */}
              <circle cx="380" cy="540" r="45" fill="#FFC0A0" opacity="0.6" />
              <circle cx="644" cy="540" r="45" fill="#FFC0A0" opacity="0.6" />

              {/* Eyes */}
              <path d="M 360,480 A 80,80 0 0,0 440,480" stroke="#4a2c2a" strokeWidth="12" fill="none" strokeLinecap="round" />
              <path d="M 584,480 A 80,80 0 0,0 664,480" stroke="#4a2c2a" strokeWidth="12" fill="none" strokeLinecap="round" />

              {/* Smile */}
              <path d="M 420,600 Q 512,680 604,600" stroke="#4a2c2a" strokeWidth="15" fill="none" strokeLinecap="round" />
            </svg>
          </div>
        )}
        {/* Clouds */}
        {clouds.map((cloud, i) => (
            <div key={i} className="absolute animate-cloud" style={{
                top: `${cloud.top}%`,
                left: `${cloud.left}%`,
                transform: `scale(${cloud.scale})`,
                animationDuration: `${cloud.speed}s`,
            }}>
                <div className="absolute w-20 h-12 bg-white rounded-full opacity-80 -top-4 -left-8"></div>
                <div className="absolute w-24 h-16 bg-white rounded-full opacity-80 -top-8 left-0"></div>
                <div className="absolute w-16 h-10 bg-white rounded-full opacity-80 -top-2 left-12"></div>
            </div>
        ))}
        {showHurry && (
          <div className="absolute top-4 left-0 right-0 flex flex-col items-center justify-center z-50">
            <h2 className="text-6xl font-bold text-white animate-pulse" style={{textShadow: '2px 2px 4px rgba(0,0,0,0.5)'}}>Hurry!</h2>
          </div>
        )}

        {/* Platforms */}
        {level.platforms.map((p) => (
          <div
            key={p.id}
            className="absolute bg-[#b5838d] border-t-2 border-[#6d4c41]"
            style={{ left: p.position.x, top: p.position.y, width: p.width, height: p.height }}
          >
            <div className="w-full h-full" style={{backgroundImage: `linear-gradient(45deg, #a56e79 25%, transparent 25%), linear-gradient(-45deg, #a56e79 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #a56e79 75%), linear-gradient(-45deg, transparent 75%, #a56e79 75%)`, backgroundSize: '20px 20px'}}></div>
          </div>
        ))}

        {/* Coins */}
        {coins.map((c) => (
            <div
                key={c.id}
                className="absolute flex items-center justify-center rounded-full"
                style={{ left: c.pos.x, top: c.pos.y, width: COIN_SIZE, height: COIN_SIZE }}
            >
                <div className="w-full h-full bg-yellow-400 rounded-full border-2 border-yellow-600 shadow-inner">
                    <span className="absolute inset-0 flex items-center justify-center text-yellow-700 font-bold text-sm">$</span>
                </div>
            </div>
        ))}

        {/* Enemies */}
        {enemies.map((e) => {
            const enemyLegMovementClass = e.vel.x !== 0 ? 'animate-walk' : '';
            return (
            <div key={e.id} className="absolute" style={{ left: e.pos.x, top: e.pos.y, width: ENEMY_WIDTH, height: PLAYER_HEIGHT, transform: e.vel.x > 0 ? 'scaleX(1)' : 'scaleX(-1)'  }}>
              <div className={cn("relative w-full h-full", enemyLegMovementClass)}>
                {/* Head */}
                <div className="absolute w-1/2 h-1/3 top-[5%] left-1/4 bg-gray-800 rounded-full border-2 border-gray-900"></div>
                {/* Body */}
                <div className="absolute w-full h-1/2 top-[30%] left-0 bg-gray-700 rounded-t-lg"></div>
                {/* Legs */}
                 <div className="absolute bottom-0 w-full h-1/5">
                  <div className="absolute left-[15%] w-[30%] h-full bg-gray-800 leg-1 rounded-b-md"></div>
                  <div className="absolute right-[15%] w-[30%] h-full bg-gray-800 leg-2 rounded-b-md"></div>
                </div>
              </div>
            </div>
            )
        })}
        
        {/* Player */}
        <div
            className="absolute"
            style={{ left: playerVisualPos.x, top: playerVisualPos.y, width: PLAYER_WIDTH, height: PLAYER_HEIGHT, transform: playerDirection === 'left' ? 'scaleX(-1)' : 'scaleX(1)' }}
        >
            <div className={cn("relative w-full h-full", playerLegMovementClass)}>
                {/* Head */}
                <div className="absolute w-1/2 h-1/3 top-[5%] left-1/4 bg-yellow-200 rounded-full border-2 border-yellow-400"></div>
                {/* Body */}
                <div className="absolute w-full h-1/2 top-[30%] left-0 bg-blue-500 rounded-t-lg"></div>
                {/* Legs */}
                <div className="absolute bottom-0 w-full h-1/5">
                  <div className="absolute left-[15%] w-[30%] h-full bg-blue-800 leg-1 rounded-b-md"></div>
                  <div className="absolute right-[15%] w-[30%] h-full bg-blue-800 leg-2 rounded-b-md"></div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
}
