'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Coins } from 'lucide-react';

type StartScreenProps = {
  onStart: () => void;
};

export function StartScreen({ onStart }: StartScreenProps) {
  return (
    <Card className="w-full max-w-md text-center border-2 border-primary/50 shadow-lg shadow-primary/20">
      <CardHeader>
        <div className="flex justify-center items-center gap-4">
           <Coins className="w-12 h-12 text-accent" />
            <CardTitle className="text-5xl font-bold text-foreground font-headline tracking-wider">Coin Quest 2D</CardTitle>
           <Coins className="w-12 h-12 text-accent" />
        </div>
        <CardDescription className="text-lg text-muted-foreground pt-2">A classic 2D platformer adventure.</CardDescription>
        <p className="text-sm text-muted-foreground">Made by Nikolay Vetsov</p>
        <p className="text-xs text-muted-foreground mt-1">Created using Firebase Studio</p>
      </CardHeader>
      <CardContent className="p-8 pt-2">
        <div className="mb-6 space-y-2">
          <p>Use Arrow Keys to move and Space to jump / double jump.</p>
          <p>Collect all coins to complete the level!</p>
        </div>
        <Button onClick={onStart} size="lg" className="w-full text-lg font-bold">
          Start Game
        </Button>
      </CardContent>
    </Card>
  );
}
