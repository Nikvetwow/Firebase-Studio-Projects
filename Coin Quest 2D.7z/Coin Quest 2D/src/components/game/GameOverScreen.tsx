'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

type GameOverScreenProps = {
  onRestart: () => void;
};

export function GameOverScreen({ onRestart }: GameOverScreenProps) {
  return (
    <Card className="w-full max-w-md text-center border-2 border-destructive/50 shadow-lg shadow-destructive/20">
      <CardHeader>
        <CardTitle className="text-5xl font-bold text-destructive font-headline">Game Over</CardTitle>
        <CardDescription className="text-lg text-muted-foreground pt-2">You've run out of lives!</CardDescription>
      </CardHeader>
      <CardContent className="p-8 pt-2">
        <p className="mb-6">Don't give up! The treasure awaits.</p>
        <Button onClick={onRestart} size="lg" className="w-full text-lg font-bold" variant="destructive">
          Restart
        </Button>
      </CardContent>
    </Card>
  );
}
