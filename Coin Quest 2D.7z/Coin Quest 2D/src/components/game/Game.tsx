'use client';

import { useState, useMemo } from 'react';
import { StartScreen } from '@/components/game/StartScreen';
import { GameOverScreen } from '@/components/game/GameOverScreen';
import { GameArea } from '@/components/game/GameArea';
import { levels } from '@/lib/game/levels';
import { INITIAL_LIVES } from '@/lib/game/constants';
import { SoundManager } from '@/lib/game/sounds';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export function Game() {
  const [gameState, setGameState] = useState<
    'start' | 'playing' | 'game-over' | 'game-complete' | 'level-transition'
  >('start');
  const [levelIndex, setLevelIndex] = useState(0); 
  const [lives, setLives] = useState(INITIAL_LIVES);
  const [gameKey, setGameKey] = useState(Date.now());

  const sunPositions = useMemo(() => {
    return levels.map(() => ({
      top: Math.random() * 20 + 5,
      left: Math.random() * 80 + 10,
    }));
  }, []);

  const cloudPositions = useMemo(() => {
    return levels.map(() => {
        const numClouds = Math.floor(Math.random() * 3) + 3; // 3 to 5 clouds per level
        return Array.from({length: numClouds}, () => ({
            top: Math.random() * 40 + 5, // position in top 45% of screen
            left: Math.random() * 80 + 10,
            scale: Math.random() * 0.5 + 0.8, // give some size variation
            speed: Math.random() * 5 + 5 // animation duration
        }));
    });
  }, []);

  const startGame = async () => {
    await SoundManager.init();
    setLevelIndex(0); 
    setLives(INITIAL_LIVES);
    setGameState('playing');
    setGameKey(Date.now());
  };

  const restartGame = () => {
    setLevelIndex(0); // Reset to level 1 on full restart
    setGameState('start');
  };

  const handlePlayerDeath = () => {
    SoundManager.hurt();
    if (lives - 1 > 0) {
      setLives((prev) => prev - 1);
      setGameKey(Date.now()); // Remount GameArea to restart level
    } else {
      setLives(0);
      SoundManager.gameOver();
      setGameState('game-over');
    }
  };

  const handleLevelRestart = () => {
    if (lives > 1) {
      SoundManager.hurt();
      setLives((prev) => prev - 1);
      setGameKey(Date.now());
    }
  };

  const handleLevelComplete = () => {
    SoundManager.levelComplete();
    if (levelIndex + 1 < levels.length) {
      setGameState('level-transition');
      setTimeout(() => {
        setLevelIndex((prev) => prev + 1);
        setGameState('playing');
        setGameKey(Date.now());
      }, 2500);
    } else {
      setGameState('game-complete');
    }
  };

  const renderGameState = () => {
    switch (gameState) {
      case 'start':
        return <StartScreen onStart={startGame} />;
      case 'game-over':
        return <GameOverScreen onRestart={restartGame} />;
      case 'playing':
        return (
          <GameArea
            key={gameKey}
            level={levels[levelIndex]}
            onLevelComplete={handleLevelComplete}
            onPlayerDeath={handlePlayerDeath}
            onLevelRestart={handleLevelRestart}
            lives={lives}
            levelIndex={levelIndex}
            sunPosition={sunPositions[levelIndex]}
            clouds={cloudPositions[levelIndex]}
          />
        );
      case 'level-transition':
        return (
          <div className="flex flex-col items-center justify-center h-full text-foreground font-headline">
            <h2 className="text-5xl font-bold animate-bounce">Level {levelIndex + 2}</h2>
            <p className="mt-4 text-xl">Get Ready!</p>
          </div>
        );
      case 'game-complete':
        return (
          <Card className="w-full max-w-md text-center">
            <CardContent className="p-8">
              <h1 className="text-4xl font-bold text-accent mb-4">You Win!</h1>
              <p className="text-lg text-foreground mb-6">Congratulations, you have completed Coin Quest 2D!</p>
              <Button onClick={restartGame}>Play Again</Button>
            </CardContent>
          </Card>
        );
      default:
        return null;
    }
  };

  return (
    <div className="text-foreground font-headline flex items-center justify-center w-full h-full">
      {renderGameState()}
    </div>
  );
}
