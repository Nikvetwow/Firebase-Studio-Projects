
import type { Level } from './types';
import { GAME_WIDTH, GAME_HEIGHT, ENEMY_WIDTH, COIN_SIZE } from './constants';

export const levels: Level[] = [
  // Level 1: Introduction
  {
    id: 1,
    playerStart: { x: 50, y: 500 },
    platforms: [
      { id: 'p1-1', position: { x: 0, y: 550 }, width: GAME_WIDTH, height: 50 },
      { id: 'p1-2', position: { x: 200, y: 450 }, width: 150, height: 20 },
      { id: 'p1-3', position: { x: 450, y: 380 }, width: 200, height: 20 },
      { id: 'p1-4', position: { x: 250, y: 280 }, width: 100, height: 20 },
      { id: 'p1-5', position: { x: 600, y: 200 }, width: 150, height: 20 },
    ],
    coins: [
      { id: 'c1-1', position: { x: 250, y: 420 } },
      { id: 'c1-2', position: { x: 500, y: 350 } },
      { id: 'c1-3', position: { x: 650, y: 170 } },
    ],
    enemies: [
      { id: 'e1-1', position: { x: 460, y: 332 }, patrolRange: { startX: 450, endX: 650 } },
    ],
  },
  // Level 2: More jumping
  {
    id: 2,
    playerStart: { x: 50, y: 100 },
    platforms: [
      { id: 'p2-1', position: { x: 0, y: 550 }, width: 200, height: 50 },
      { id: 'p2-2', position: { x: 300, y: 500 }, width: 200, height: 20 },
      { id: 'p2-3', position: { x: 600, y: 450 }, width: 200, height: 20 },
      { id: 'p2-4', position: { x: 400, y: 350 }, width: 150, height: 20 },
      { id: 'p2-5', position: { x: 150, y: 250 }, width: 200, height: 20 },
      { id: 'p2-6', position: { x: 0, y: 150 }, width: 100, height: 20 },
      { id: 'p2-7', position: { x: 700, y: 150 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c2-1', position: { x: 350, y: 470 } },
      { id: 'c2-2', position: { x: 650, y: 420 } },
      { id: 'c2-3', position: { x: 200, y: 220 } },
      { id: 'c2-5', position: { x: 750, y: 120 } },
    ],
    enemies: [
      { id: 'e2-1', position: { x: 310, y: 452 }, patrolRange: { startX: 300, endX: 500 } },
      { id: 'e2-2', position: { x: 160, y: 202 }, patrolRange: { startX: 150, endX: 350 } },
    ],
  },
   // Level 3: Danger Zone
  {
    id: 3,
    playerStart: { x: 380, y: 100 },
    platforms: [
      { id: 'p3-1', position: { x: 350, y: 150 }, width: 100, height: 20 },
      { id: 'p3-2', position: { x: 0, y: 550 }, width: 150, height: 50 },
      { id: 'p3-3', position: { x: 650, y: 550 }, width: 150, height: 50 },
      { id: 'p3-4', position: { x: 250, y: 450 }, width: 300, height: 20 },
      { id: 'p3-5', position: { x: 100, y: 350 }, width: 100, height: 20 },
      { id: 'p3-6', position: { x: 600, y: 350 }, width: 100, height: 20 },
      { id: 'p3-7', position: { x: 350, y: 250 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c3-1', position: { x: 50, y: 520 } },
      { id: 'c3-2', position: { x: 700, y: 520 } },
      { id: 'c3-3', position: { x: 150, y: 320 } },
      { id: 'c3-4', position: { x: 650, y: 320 } },
      { id: 'c3-5', position: { x: 400, y: 220 } },
    ],
    enemies: [
      { id: 'e3-1', position: { x: 260, y: 402 }, patrolRange: { startX: 250, endX: 550 } },
      { id: 'e3-2', position: { x: 450, y: 402 }, patrolRange: { startX: 250, endX: 550 } },
    ],
  },
  // Level 4
  {
    id: 4,
    playerStart: { x: 50, y: 500 },
    platforms: [
      { id: 'p4-1', position: { x: 0, y: 550 }, width: GAME_WIDTH, height: 50 },
      { id: 'p4-2', position: { x: 150, y: 480 }, width: 100, height: 20 },
      { id: 'p4-3', position: { x: 300, y: 410 }, width: 100, height: 20 },
      { id: 'p4-4', position: { x: 450, y: 340 }, width: 100, height: 20 },
      { id: 'p4-5', position: { x: 600, y: 270 }, width: 100, height: 20 },
      { id: 'p4-6', position: { x: 450, y: 200 }, width: 100, height: 20 },
      { id: 'p4-7', position: { x: 300, y: 130 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c4-1', position: { x: 180, y: 450 } },
      { id: 'c4-2', position: { x: 330, y: 380 } },
      { id: 'c4-3', position: { x: 480, y: 310 } },
      { id: 'c4-4', position: { x: 630, y: 240 } },
      { id: 'c4-5', position: { x: 330, y: 100 } },
    ],
    enemies: [
       { id: 'e4-1', position: { x: 400, y: 502 }, patrolRange: { startX: 250, endX: 500 } },
    ],
  },
  // Level 5
  {
    id: 5,
    playerStart: { x: 750, y: 100 },
    platforms: [
      { id: 'p5-1', position: { x: 0, y: 550 }, width: 250, height: 50 },
      { id: 'p5-2', position: { x: 300, y: 550 }, width: 250, height: 50 },
      { id: 'p5-3', position: { x: 600, y: 550 }, width: 200, height: 50 },
      { id: 'p5-4', position: { x: 100, y: 450 }, width: 100, height: 20 },
      { id: 'p5-5', position: { x: 400, y: 450 }, width: 100, height: 20 },
      { id: 'p5-6', position: { x: 650, y: 450 }, width: 100, height: 20 },
      { id: 'p5-7', position: { x: 250, y: 250 }, width: 300, height: 20 },
      { id: 'p5-8', position: { x: 700, y: 150 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c5-1', position: { x: 150, y: 420 } },
      { id: 'c5-2', position: { x: 450, y: 420 } },
      { id: 'c5-3', position: { x: 700, y: 420 } },
      { id: 'c5-4', position: { x: 380, y: 220 } },
    ],
    enemies: [
      { id: 'e5-1', position: { x: 260, y: 202 }, patrolRange: { startX: 250, endX: 550 } },
      { id: 'e5-2', position: { x: 400, y: 502 }, patrolRange: { startX: 300, endX: 550 } },
    ],
  },
  // Level 6
  {
    id: 6,
    playerStart: { x: 380, y: 500 },
    platforms: [
      { id: 'p6-1', position: { x: 0, y: 550 }, width: GAME_WIDTH, height: 50 },
      { id: 'p6-2', position: { x: 100, y: 450 }, width: 20, height: 100 },
      { id: 'p6-3', position: { x: 200, y: 380 }, width: 20, height: 170 },
      { id: 'p6-4', position: { x: 300, y: 310 }, width: 20, height: 240 },
      { id: 'p6-5', position: { x: 500, y: 310 }, width: 20, height: 240 },
      { id: 'p6-6', position: { x: 600, y: 380 }, width: 20, height: 170 },
      { id: 'p6-7', position: { x: 700, y: 450 }, width: 20, height: 100 },
      { id: 'p6-8', position: { x: 350, y: 200 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c6-1', position: { x: 100, y: 420 } },
      { id: 'c6-2', position: { x: 200, y: 350 } },
      { id: 'c6-3', position: { x: 700, y: 420 } },
      { id: 'c6-4', position: { x: 600, y: 350 } },
      { id: 'c6-5', position: { x: 400, y: 170 } },
    ],
    enemies: [],
  },
  // Level 7
  {
    id: 7,
    playerStart: { x: 50, y: 100 },
    platforms: [
      { id: 'p7-1', position: { x: 0, y: 150 }, width: 100, height: 20 },
      { id: 'p7-2', position: { x: 200, y: 150 }, width: 50, height: 20 },
      { id: 'p7-3', position: { x: 350, y: 150 }, width: 50, height: 20 },
      { id: 'p7-4', position: { x: 500, y: 150 }, width: 50, height: 20 },
      { id: 'p7-5', position: { x: 650, y: 150 }, width: 100, height: 20 },
      { id: 'p7-6', position: { x: 0, y: 550 }, width: GAME_WIDTH, height: 50 },
      { id: 'p7-7', position: { x: 375, y: 350 }, width: 50, height: 200 },
    ],
    coins: [
      { id: 'c7-1', position: { x: 210, y: 120 } },
      { id: 'c7-2', position: { x: 360, y: 120 } },
      { id: 'c7-3', position: { x: 510, y: 120 } },
      { id: 'c7-4', position: { x: 385, y: 320 } },
    ],
    enemies: [
      { id: 'e7-1', position: { x: 100, y: 502 }, patrolRange: { startX: 0, endX: 375 } },
      { id: 'e7-2', position: { x: 600, y: 502 }, patrolRange: { startX: 425, endX: 768 } },
    ],
  },
  // Level 8
  {
    id: 8,
    playerStart: { x: 50, y: 500 },
    platforms: [
      { id: 'p8-1', position: { x: 0, y: 550 }, width: 100, height: 50 },
      { id: 'p8-2', position: { x: 150, y: 500 }, width: 100, height: 20 },
      { id: 'p8-3', position: { x: 300, y: 450 }, width: 100, height: 20 },
      { id: 'p8-4', position: { x: 450, y: 400 }, width: 100, height: 20 },
      { id: 'p8-5', position: { x: 600, y: 350 }, width: 100, height: 20 },
      { id: 'p8-6', position: { x: 450, y: 250 }, width: 100, height: 20 },
      { id: 'p8-7', position: { x: 300, y: 180 }, width: 100, height: 20 },
      { id: 'p8-8', position: { x: 150, y: 180 }, width: 100, height: 20 },
      { id: 'p8-9', position: { x: 0, y: 250 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c8-1', position: { x: 200, y: 470 } },
      { id: 'c8-2', position: { x: 500, y: 370 } },
      { id: 'c8-3', position: { x: 70, y: 220 } },
      { id: 'c8-4', position: { x: 200, y: 150 } },
    ],
    enemies: [
      { id: 'e8-1', position: { x: 310, y: 402 }, patrolRange: { startX: 300, endX: 400 } },
      { id: 'e8-2', position: { x: 460, y: 202 }, patrolRange: { startX: 450, endX: 550 } },
    ],
  },
  // Level 9
  {
    id: 9,
    playerStart: { x: 380, y: 100 },
    platforms: [
      { id: 'p9-1', position: { x: 350, y: 150 }, width: 100, height: 20 },
      { id: 'p9-2', position: { x: 0, y: 550 }, width: GAME_WIDTH, height: 50 },
      { id: 'p9-3', position: { x: 100, y: 450 }, width: 600, height: 20 },
      { id: 'p9-4', position: { x: 100, y: 350 }, width: 600, height: 20 },
      { id: 'p9-5', position: { x: 100, y: 250 }, width: 600, height: 20 },
    ],
    coins: [
      { id: 'c9-1', position: { x: 120, y: 220 } },
      { id: 'c9-2', position: { x: 680, y: 220 } },
      { id: 'c9-3', position: { x: 120, y: 320 } },
      { id: 'c9-4', position: { x: 680, y: 320 } },
      { id: 'c9-5', position: { x: 120, y: 420 } },
      { id: 'c9-6', position: { x: 680, y: 420 } },
    ],
    enemies: [
      { id: 'e9-1', position: { x: 110, y: 202 }, patrolRange: { startX: 100, endX: 700 } },
      { id: 'e9-2', position: { x: 650, y: 302 }, patrolRange: { startX: 100, endX: 700 } },
      { id: 'e9-3', position: { x: 110, y: 402 }, patrolRange: { startX: 100, endX: 700 } },
      { id: 'e9-4', position: { x: 690, y: 502 }, patrolRange: { startX: 0, endX: GAME_WIDTH } },
    ],
  },
  // Level 10
  {
    id: 10,
    playerStart: { x: 50, y: 500 },
    platforms: [
      { id: 'p10-1', position: { x: 0, y: 550 }, width: 100, height: 50 },
      { id: 'p10-2', position: { x: 700, y: 550 }, width: 100, height: 50 },
      { id: 'p10-3', position: { x: 150, y: 480 }, width: 500, height: 20 },
      { id: 'p10-4', position: { x: 200, y: 400 }, width: 20, height: 80 },
      { id: 'p10-5', position: { x: 580, y: 400 }, width: 20, height: 80 },
      { id: 'p10-6', position: { x: 300, y: 350 }, width: 200, height: 20 },
      { id: 'p10-7', position: { x: 390, y: 270 }, width: 20, height: 80 },
      { id: 'p10-8', position: { x: 100, y: 150 }, width: 600, height: 20 },
      { id: 'p10-9', position: { x: 50, y: 250 }, width: 50, height: 20 },
      { id: 'p10-10', position: { x: 700, y: 250 }, width: 50, height: 20 },
    ],
    coins: [
      { id: 'c10-2', position: { x: 750, y: 520 } },
      { id: 'c10-3', position: { x: 450, y: 320 } },
      { id: 'c10-4', position: { x: 120, y: 120 } },
      { id: 'c10-5', position: { x: 680, y: 120 } },
    ],
    enemies: [
      { id: 'e10-1', position: { x: 400, y: 432 }, patrolRange: { startX: 250, endX: 500 } },
      { id: 'e10-2', position: { x: 150, y: 102 }, patrolRange: { startX: 100, endX: 380 } },
      { id: 'e10-3', position: { x: 430, y: 102 }, patrolRange: { startX: 420, endX: 700 } },
    ],
  },
  // Level 11
  {
    id: 11,
    playerStart: { x: 50, y: 500 },
    platforms: [
      { id: 'p11-1', position: { x: 0, y: 550 }, width: 150, height: 50 },
      { id: 'p11-2', position: { x: 200, y: 500 }, width: 50, height: 20 },
      { id: 'p11-3', position: { x: 300, y: 450 }, width: 50, height: 20 },
      { id: 'p11-4', position: { x: 400, y: 400 }, width: 50, height: 20 },
      { id: 'p11-5', position: { x: 500, y: 350 }, width: 50, height: 20 },
      { id: 'p11-6', position: { x: 600, y: 300 }, width: 50, height: 20 },
      { id: 'p11-7', position: { x: 700, y: 250 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c11-1', position: { x: 210, y: 470 } },
      { id: 'c11-2', position: { x: 310, y: 420 } },
      { id: 'c11-3', position: { x: 410, y: 370 } },
      { id: 'c11-4', position: { x: 510, y: 320 } },
      { id: 'c11-5', position: { x: 610, y: 270 } },
      { id: 'c11-6', position: { x: 750, y: 220 } },
    ],
    enemies: [],
  },
  // Level 12
  {
    id: 12,
    playerStart: { x: 750, y: 500 },
    platforms: [
      { id: 'p12-1', position: { x: 650, y: 550 }, width: 150, height: 50 },
      { id: 'p12-2', position: { x: 550, y: 500 }, width: 50, height: 20 },
      { id: 'p12-3', position: { x: 450, y: 450 }, width: 50, height: 20 },
      { id: 'p12-4', position: { x: 350, y: 400 }, width: 50, height: 20 },
      { id: 'p12-5', position: { x: 250, y: 350 }, width: 50, height: 20 },
      { id: 'p12-6', position: { x: 150, y: 300 }, width: 50, height: 20 },
      { id: 'p12-7', position: { x: 0, y: 250 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c12-1', position: { x: 560, y: 470 } },
      { id: 'c12-2', position: { x: 460, y: 420 } },
      { id: 'c12-3', position: { x: 360, y: 370 } },
      { id: 'c12-4', position: { x: 260, y: 320 } },
      { id: 'c12-5', position: { x: 160, y: 270 } },
      { id: 'c12-6', position: { x: 50, y: 220 } },
    ],
    enemies: [],
  },
  // Level 13
  {
    id: 13,
    playerStart: { x: 150, y: 402 },
    platforms: [
      { id: 'p13-1', position: { x: 0, y: 550 }, width: GAME_WIDTH, height: 50 },
      { id: 'p13-2', position: { x: 100, y: 450 }, width: 100, height: 20 },
      { id: 'p13-3', position: { x: 600, y: 450 }, width: 100, height: 20 },
      { id: 'p13-4', position: { x: 350, y: 350 }, width: 100, height: 20 },
      { id: 'p13-5', position: { x: 100, y: 250 }, width: 100, height: 20 },
      { id: 'p13-6', position: { x: 600, y: 250 }, width: 100, height: 20 },
      { id: 'p13-7', position: { x: 350, y: 150 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c13-2', position: { x: 650, y: 420 } },
      { id: 'c13-3', position: { x: 400, y: 320 } },
      { id: 'c13-4', position: { x: 150, y: 220 } },
      { id: 'c13-5', position: { x: 650, y: 220 } },
      { id: 'c13-6', position: { x: 400, y: 120 } },
    ],
    enemies: [
      { id: 'e13-1', position: { x: 300, y: 502 }, patrolRange: { startX: 250, endX: 550 } },
      { id: 'e13-2', position: { x: 400, y: 502 }, patrolRange: { startX: 250, endX: 550 } },
    ],
  },
  // Level 14
  {
    id: 14,
    playerStart: { x: 70, y: 82 },
    platforms: [
      { id: 'p14-1', position: { x: 0, y: 550 }, width: 800, height: 50 }, // Ground
      { id: 'p14-2', position: { x: 50, y: 150 }, width: 50, height: 400 }, // Left wall
      { id: 'p14-3', position: { x: 700, y: 150 }, width: 50, height: 400 }, // Right wall
      { id: 'p14-4', position: { x: 200, y: 350 }, width: 400, height: 20 }, // Middle platform
      { id: 'p14-5', position: { x: 380, y: 150 }, width: 40, height: 200 }, // Central hanging wall
    ],
    coins: [
      { id: 'c14-1', position: { x: 125, y: 502 } },
      { id: 'c14-2', position: { x: 650, y: 502 } },
      { id: 'c14-3', position: { x: 220, y: 320 } },
      { id: 'c14-4', position: { x: 550, y: 320 } },
      { id: 'c14-5', position: { x: 450, y: 502 } },
      { id: 'c14-6', position: { x: 390, y: 120 } },
    ],
    enemies: [
        { id: 'e14-1', position: { x: 110, y: 502 }, patrolRange: { startX: 100, endX: 700 - ENEMY_WIDTH } },
        { id: 'e14-2', position: { x: 210, y: 302 }, patrolRange: { startX: 200, endX: 380 } },
        { id: 'e14-3', position: { x: 430, y: 302 }, patrolRange: { startX: 420, endX: 600 } },
    ],
  },
  // Level 15
  {
    id: 15,
    playerStart: { x: 380, y: 50 },
    platforms: [
      { id: 'p15-1', position: { x: 350, y: 100 }, width: 100, height: 20 },
      { id: 'p15-2', position: { x: 200, y: 180 }, width: 20, height: 20 },
      { id: 'p15-3', position: { x: 580, y: 180 }, width: 20, height: 20 },
      { id: 'p15-4', position: { x: 100, y: 260 }, width: 20, height: 20 },
      { id: 'p15-5', position: { x: 680, y: 260 }, width: 20, height: 20 },
      { id: 'p15-6', position: { x: 0, y: 340 }, width: 20, height: 20 },
      { id: 'p15-7', position: { x: 780, y: 340 }, width: 20, height: 20 },
      { id: 'p15-8', position: { x: 0, y: 550 }, width: 800, height: 50 },
    ],
    coins: [
      { id: 'c15-1', position: { x: 200, y: 150 } },
      { id: 'c15-2', position: { x: 580, y: 150 } },
      { id: 'c15-3', position: { x: 100, y: 230 } },
      { id: 'c15-4', position: { x: 680, y: 230 } },
      { id: 'c15-5', position: { x: 0, y: 310 } },
      { id: 'c15-6', position: { x: 780, y: 310 } },
    ],
    enemies: [
      { id: 'e15-1', position: { x: 100, y: 502 }, patrolRange: { startX: 0, endX: 780 } },
      { id: 'e15-2', position: { x: 700, y: 502 }, patrolRange: { startX: 0, endX: 780 } },
    ],
  },
  // Level 16
  {
    id: 16,
    playerStart: { x: 660, y: 82 },
    platforms: [
      { id: 'p16-1', position: { x: 0, y: 550 }, width: 800, height: 50 },
      { id: 'p16-2', position: { x: 150, y: 480 }, width: 20, height: 70 },
      { id: 'p16-3', position: { x: 250, y: 410 }, width: 20, height: 140 },
      { id: 'p16-4', position: { x: 350, y: 340 }, width: 20, height: 210 },
      { id: 'p16-5', position: { x: 450, y: 270 }, width: 20, height: 280 },
      { id: 'p16-6', position: { x: 550, y: 200 }, width: 20, height: 350 },
      { id: 'p16-7', position: { x: 650, y: 130 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c16-1', position: { x: 160 - COIN_SIZE / 2, y: 450 } },
      { id: 'c16-2', position: { x: 260 - COIN_SIZE / 2, y: 380 } },
      { id: 'c16-3', position: { x: 360 - COIN_SIZE / 2, y: 310 } },
      { id: 'c16-4', position: { x: 460 - COIN_SIZE / 2, y: 240 } },
      { id: 'c16-5', position: { x: 560 - COIN_SIZE / 2, y: 170 } },
      { id: 'c16-6', position: { x: 700 - COIN_SIZE / 2, y: 100 } },
    ],
    enemies: [
      { id: 'e16-1', position: { x: 10, y: 502 }, patrolRange: { startX: 0, endX: 150 } },
      { id: 'e16-2', position: { x: 180, y: 502 }, patrolRange: { startX: 170, endX: 250 } },
      { id: 'e16-3', position: { x: 280, y: 502 }, patrolRange: { startX: 270, endX: 350 } },
      { id: 'e16-4', position: { x: 380, y: 502 }, patrolRange: { startX: 370, endX: 450 } },
      { id: 'e16-5', position: { x: 480, y: 502 }, patrolRange: { startX: 470, endX: 550 } },
      { id: 'e16-6', position: { x: 580, y: 502 }, patrolRange: { startX: 570, endX: 800 } },
    ],
  },
  // Level 17
  {
    id: 17,
    playerStart: { x: 380, y: 100 },
    platforms: [
      { id: 'p17-1', position: { x: 350, y: 150 }, width: 100, height: 20 },
      { id: 'p17-2', position: { x: 0, y: 550 }, width: 100, height: 50 },
      { id: 'p17-3', position: { x: 150, y: 550 }, width: 100, height: 50 },
      { id: 'p17-4', position: { x: 300, y: 550 }, width: 100, height: 50 },
      { id: 'p17-5', position: { x: 450, y: 550 }, width: 100, height: 50 },
      { id: 'p17-6', position: { x: 600, y: 550 }, width: 100, height: 50 },
      { id: 'p17-7', position: { x: 750, y: 550 }, width: 50, height: 50 },
      { id: 'p17-8', position: { x: 200, y: 300 }, width: 400, height: 20 },
    ],
    coins: [
      { id: 'c17-1', position: { x: 50 - COIN_SIZE / 2 + 50, y: 520 } },
      { id: 'c17-2', position: { x: 150 - COIN_SIZE / 2 + 50, y: 520 } },
      { id: 'c17-3', position: { x: 300 - COIN_SIZE / 2 + 50, y: 520 } },
      { id: 'c17-4', position: { x: 450 - COIN_SIZE / 2 + 50, y: 520 } },
      { id: 'c17-5', position: { x: 600 - COIN_SIZE / 2 + 50, y: 520 } },
      { id: 'c17-6', position: { x: 400 - COIN_SIZE / 2, y: 270 } },
    ],
    enemies: [
      { id: 'e17-1', position: { x: 210, y: 252 }, patrolRange: { startX: 200, endX: 600 - ENEMY_WIDTH } },
      { id: 'e17-2', position: { x: 400, y: 252 }, patrolRange: { startX: 200, endX: 600 - ENEMY_WIDTH } },
    ],
  },
  // Level 18
  {
    id: 18,
    playerStart: { x: 50, y: 500 },
    platforms: [
      { id: 'p18-1', position: { x: 0, y: 550 }, width: 100, height: 50 },
      { id: 'p18-2', position: { x: 700, y: 550 }, width: 100, height: 50 },
      { id: 'p18-3', position: { x: 150, y: 450 }, width: 500, height: 20 },
      { id: 'p18-4', position: { x: 150, y: 470 }, width: 20, height: 80 },
      { id: 'p18-5', position: { x: 630, y: 470 }, width: 20, height: 80 },
      { id: 'p18-6', position: { x: 250, y: 250 }, width: 300, height: 20 },
      { id: 'p18-7', position: { x: 380, y: 270 }, width: 40, height: 180 },
    ],
    coins: [
      { id: 'c18-2', position: { x: 750, y: 520 } },
      { id: 'c18-3', position: { x: 160, y: 420 } },
      { id: 'c18-4', position: { x: 620, y: 420 } },
      { id: 'c18-5', position: { x: 400, y: 220 } },
    ],
    enemies: [
      { id: 'e18-1', position: { x: 160, y: 402 }, patrolRange: { startX: 150, endX: 380 } },
      { id: 'e18-2', position: { x: 430, y: 402 }, patrolRange: { startX: 420, endX: 650 } },
      { id: 'e18-3', position: { x: 260, y: 202 }, patrolRange: { startX: 250, endX: 550 } },
    ],
  },
  // Level 19
  {
    id: 19,
    playerStart: { x: 50, y: 50 },
    platforms: [
      { id: 'p19-1', position: { x: 0, y: 100 }, width: 100, height: 20 },
      { id: 'p19-2', position: { x: 0, y: 550 }, width: 800, height: 50 },
      { id: 'p19-3', position: { x: 200, y: 200 }, width: 20, height: 350 },
      { id: 'p19-4', position: { x: 400, y: 100 }, width: 20, height: 450 },
      { id: 'p19-5', position: { x: 600, y: 200 }, width: 20, height: 350 },
      { id: 'p19-6', position: { x: 700, y: 100 }, width: 100, height: 20 },
      // Stepping stones
      { id: 'p19-s1', position: { x: 150, y: 200 }, width: 50, height: 20 },
      { id: 'p19-s2', position: { x: 300, y: 200 }, width: 50, height: 20 },
      { id: 'p19-s3', position: { x: 450, y: 200 }, width: 50, height: 20 },
      { id: 'p19-s4', position: { x: 520, y: 200 }, width: 50, height: 20 },
    ],
    coins: [
      { id: 'c19-2', position: { x: 165, y: 170 } },
      { id: 'c19-3', position: { x: 315, y: 170 } },
      { id: 'c19-4', position: { x: 465, y: 170 } },
      { id: 'c19-5', position: { x: 535, y: 170 } },
      { id: 'c19-6', position: { x: 750, y: 70 } },
    ],
    enemies: [
      { id: 'e19-1', position: { x: 250, y: 502 }, patrolRange: { startX: 220, endX: 400 - ENEMY_WIDTH } },
      { id: 'e19-2', position: { x: 450, y: 502 }, patrolRange: { startX: 420, endX: 600 - ENEMY_WIDTH } },
      { id: 'e19-3', position: { x: 100, y: 502 }, patrolRange: { startX: 0, endX: 200 - ENEMY_WIDTH } },
    ],
  },
  // Level 20 - Reworked
  {
    id: 20,
    playerStart: { x: 50, y: 500 },
    platforms: [
      // Ground
      { id: 'p20-1', position: { x: 0, y: 550 }, width: 800, height: 50 },
      // Path up
      { id: 'p20-2', position: { x: 0, y: 480 }, width: 150, height: 20 }, // Start platform
      { id: 'p20-3', position: { x: 250, y: 410 }, width: 150, height: 20 },
      { id: 'p20-4', position: { x: 500, y: 340 }, width: 150, height: 20 },
      { id: 'p20-5', position: { x: 250, y: 270 }, width: 150, height: 20 },
      { id: 'p20-6', position: { x: 0, y: 200 }, width: 150, height: 20 },
      { id: 'p20-7', position: { x: 650, y: 200 }, width: 150, height: 20 },
      // Final platform
      { id: 'p20-8', position: { x: 350, y: 130 }, width: 100, height: 20 },
    ],
    coins: [
      { id: 'c20-1', position: { x: 300, y: 380 } },
      { id: 'c20-2', position: { x: 550, y: 310 } },
      { id: 'c20-3', position: { x: 300, y: 240 } },
      { id: 'c20-4', position: { x: 50, y: 170 } },
      { id: 'c20-5', position: { x: 700, y: 170 } },
      { id: 'c20-6', position: { x: 390, y: 100 } },
    ],
    enemies: [
      { id: 'e20-1', position: { x: 260, y: 362 }, patrolRange: { startX: 250, endX: 400 - ENEMY_WIDTH } },
      { id: 'e20-2', position: { x: 510, y: 292 }, patrolRange: { startX: 500, endX: 650 - ENEMY_WIDTH } },
      { id: 'e20-3', position: { x: 10, y: 152 }, patrolRange: { startX: 0, endX: 150 - ENEMY_WIDTH } },
      { id: 'e20-4', position: { x: 660, y: 152 }, patrolRange: { startX: 650, endX: 800 - ENEMY_WIDTH } },
      { id: 'e20-5', position: { x: 100, y: 502 }, patrolRange: { startX: 0, endX: GAME_WIDTH - ENEMY_WIDTH } },
    ],
  },
];

    
