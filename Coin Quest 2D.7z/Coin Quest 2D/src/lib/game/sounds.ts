'use client';

import * as Tone from 'tone';

let soundsLoaded = false;

// We will keep these synths for sounds that are not rapidly repeated.
let levelCompleteSynth: Tone.Synth;
let gameOverSound: Tone.MembraneSynth;

const initSounds = async () => {
  if (soundsLoaded) return;
  // Tone.start() is required to start the audio context in the browser.
  await Tone.start();

  levelCompleteSynth = new Tone.Synth({
    oscillator: { type: 'sine' },
    envelope: { attack: 0.1, decay: 0.3, sustain: 0.2, release: 0.5 },
  }).toDestination();

  gameOverSound = new Tone.MembraneSynth().toDestination();

  soundsLoaded = true;
  console.log('Audio context started and sounds initialized');
};

const playCoinSound = () => {
  if (!soundsLoaded) return;
  // To solve the "start time must be strictly greater" error when sounds are triggered
  // in very rapid succession (like in a game loop), we can create a new synth
  // instance on the fly. This is a bit less efficient but guarantees that we
  // don't have scheduling conflicts on a single synth instance.
  const coinSound = new Tone.Synth({
    oscillator: { type: 'triangle' },
    envelope: { attack: 0.01, decay: 0.2, sustain: 0.1, release: 0.2 },
  }).toDestination();
  
  // Play the sound immediately and schedule it for disposal.
  coinSound.triggerAttackRelease('C5', '16n', Tone.now());
  setTimeout(() => {
    coinSound.dispose();
  }, 300); // Dispose after the sound has finished playing.
};


const playHurtSound = () => {
  if (!soundsLoaded) return;
  const hurtSound = new Tone.Synth({
    oscillator: { type: 'sawtooth' },
    envelope: { attack: 0.01, decay: 0.5, sustain: 0, release: 0.1 },
  }).toDestination();
  hurtSound.triggerAttackRelease('G2', '8n', Tone.now());
  setTimeout(() => {
    hurtSound.dispose();
  }, 600);
};

const playLevelCompleteSound = () => {
  if (!soundsLoaded) return;
  const now = Tone.now();
  levelCompleteSynth.triggerAttackRelease("C4", "8n", now);
  levelCompleteSynth.triggerAttackRelease("E4", "8n", now + 0.2);
  levelCompleteSynth.triggerAttackRelease("G4", "8n", now + 0.4);
};

const playGameOverSound = () => {
  if (!soundsLoaded) return;
  gameOverSound.triggerAttackRelease('C2', '4n');
};

const playJumpSound = () => {
  // Sound removed as requested
};

export const SoundManager = {
  init: initSounds,
  coin: playCoinSound,
  hurt: playHurtSound,
  levelComplete: playLevelCompleteSound,
  gameOver: playGameOverSound,
  jump: playJumpSound,
};
