export const GAME_WIDTH = 800;
export const GAME_HEIGHT = 600;

export const PLAYER_WIDTH = 32;
export const PLAYER_HEIGHT = 48;
export const PLAYER_SPEED = 3;
export const JUMP_STRENGTH = 14;
export const GRAVITY = 0.7;

export const ENEMY_WIDTH = 32;
export const ENEMY_HEIGHT = 48;
export const ENEMY_SPEED = 1;

export const COIN_SIZE = 24;

export const INITIAL_LIVES = 5;
