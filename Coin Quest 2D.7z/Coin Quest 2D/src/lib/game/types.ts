export interface Vector2D {
  x: number;
  y: number;
}

export interface Platform {
  id: string;
  position: Vector2D;
  width: number;
  height: number;
}

export interface Coin {
  id: string;
  position: Vector2D;
}

export interface Enemy {
  id: string;
  position: Vector2D;
  patrolRange: { startX: number; endX: number };
}

export interface Level {
  id: number;
  platforms: Platform[];
  coins: Coin[];
  enemies: Enemy[];
  playerStart: Vector2D;
}
