'use client';

import { useEffect, useState } from 'react';

const
 
keysOfInterest = ['ArrowLeft', 'ArrowRight', 'Space'] as const;
type Key = (typeof keysOfInterest)[number];

export const usePlayerInput = () => {
  const [keys, setKeys] = useState<Record<Key, boolean>>({
    ArrowLeft: false,
    ArrowRight: false,
    Space: false,
  });

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (keysOfInterest.includes(event.code as Key)) {
        event.preventDefault();
        setKeys((prev) => ({ ...prev, [event.code]: true }));
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      if (keysOfInterest.includes(event.code as Key)) {
        event.preventDefault();
        setKeys((prev) => ({ ...prev, [event.code]: false }));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return keys;
};
